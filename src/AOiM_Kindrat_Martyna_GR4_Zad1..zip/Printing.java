public interface Printing {
    void print();
}
